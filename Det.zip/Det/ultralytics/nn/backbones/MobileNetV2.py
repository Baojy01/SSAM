import torch.nn as nn
import torch


def _make_divisible(v, divisor=8, min_value=None):
    """
    It ensures that all layers have a channel number that is divisible by 8.
    """
    if min_value is None:
        min_value = divisor
    new_v = max(min_value, int(v + divisor / 2) // divisor * divisor)
    # Make sure that round down does not go down by more than 10%.
    if new_v < 0.9 * v:
        new_v += divisor
    return new_v


class ConvBNReLU(nn.Sequential):
    def __init__(self, in_planes, out_planes, kernel_size=3, stride=1, groups=1, dilation=1):
        padding = (kernel_size - 1) // 2
        if dilation != 1:
            padding = dilation
        super(ConvBNReLU, self).__init__(
            nn.Conv2d(in_planes, out_planes, kernel_size, stride, padding, groups=groups, dilation=dilation,
                      bias=False),
            nn.BatchNorm2d(out_planes),
            nn.ReLU6(inplace=True)
        )


class InvertedResidual(nn.Module):
    def __init__(self, inp, oup, stride, expand_ratio, dilation=1):
        super(InvertedResidual, self).__init__()
        self.stride = stride
        assert stride in [1, 2]

        hidden_dim = int(round(inp * expand_ratio))
        self.use_res_connect = self.stride == 1 and inp == oup

        layers = []
        if expand_ratio != 1:
            # pw
            layers.append(ConvBNReLU(inp, hidden_dim, kernel_size=1))
        layers.extend([
            # dw
            ConvBNReLU(hidden_dim, hidden_dim, stride=stride, groups=hidden_dim, dilation=dilation),
            # pw-linear
            nn.Conv2d(hidden_dim, oup, 1, 1, 0, bias=False),
            nn.BatchNorm2d(oup),
        ])
        self.conv = nn.Sequential(*layers)

    def forward(self, x):
        if self.use_res_connect:
            return x + self.conv(x)
        else:
            return self.conv(x)


class MobileNetV2(nn.Module):
    def __init__(self, width_mult=1.0):
        super(MobileNetV2, self).__init__()
        block = InvertedResidual
        input_channel = 32
        last_channel = 1280
        inverted_residual_setting = [
            # t, c, n, s
            [1, 16, 1, 1],
            [6, 24, 2, 2],
            [6, 32, 3, 2],
            [6, 64, 4, 2],
            [6, 96, 3, 1],
            [6, 160, 3, 2],
            [6, 320, 1, 1],
        ]

        self.dim_list = [_make_divisible(i * width_mult) for i in [24, 32, 96, 320]]
        # building first layer
        input_channel = _make_divisible(input_channel * width_mult)

        # self.seg_begin_channel = _make_divisible(24 * width_mult)
        self.last_channel = _make_divisible(last_channel * max(1.0, width_mult))

        features = [ConvBNReLU(3, input_channel, stride=2)]
        # building inverted residual blocks
        for t, c, n, s in inverted_residual_setting:
            output_channel = _make_divisible(c * width_mult)
            for i in range(n):
                stride = s if i == 0 else 1
                features.append(block(input_channel, output_channel, stride, expand_ratio=t))
                input_channel = output_channel

        # building last several layers
        # features.append(ConvBNReLU(input_channel, self.last_channel, kernel_size=1))
        # make it nn.Sequential
        self.features = nn.Sequential(*features)
        # self.dim_list.append(self.last_channel)

        # weight initialization
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.zeros_(m.bias)

        self.layer1 = self.features[:4]
        self.layer2 = self.features[4:7]
        self.layer3 = self.features[7:14]
        self.layer4 = self.features[14:]

    def forward(self, x):
        x1 = self.layer1(x)     # 4x down
        x2 = self.layer2(x1)    # 8x down
        x3 = self.layer3(x2)    # 16x down
        x4 = self.layer4(x3)    # 32x down
        out_list = [x1, x2, x3, x4]
        return out_list


def mobilenet_v2_075(width_mult=0.75):
    model = MobileNetV2(width_mult=width_mult)
    return model


def mobilenet_v2_10(width_mult=1.0):
    model = MobileNetV2(width_mult=width_mult)
    return model


def mobilenet_v2_14(width_mult=1.4):
    model = MobileNetV2(width_mult=width_mult)
    return model


def mobilenet_v2_20(width_mult=2.0):
    model = MobileNetV2(width_mult=width_mult)
    return model


if __name__ == '__main__':
    import torch
    x0 = torch.rand(1, 3, 224, 224)
    net = mobilenet_v2_10()
    dim_list = net.dim_list
    y = net(x0)
    print(y[0].shape, '\n', y[1].shape,  '\n', y[2].shape,  '\n', y[3].shape)
    print(dim_list)
